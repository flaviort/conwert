<?php

/**
 *
 * @package templates/default
 *
 */

defined('ABSPATH') || defined('DUPXABSPATH') || exit;

dupxTplRender('pages-parts/head/header-main', array(
    'htmlTitle'         => 'Step <span class="step">3</span> of 4: ' .
        'Update Data <div class="sub-header">This step will update the database and config files to match your new sites values.</div>',
    'showInstallerMode' => false,
    'showSwitchView'    => false,
    'showInstallerLog'  => true
));
